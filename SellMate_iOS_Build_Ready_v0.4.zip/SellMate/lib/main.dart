import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const navy = Color(0xFF14243A);
const green = Color(0xFF16A67A);
const bg = Color(0xFFF4F7FB);
const defaultBusinessPhone = '+96179162328';
const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const supabaseAnon = String.fromEnvironment('SUPABASE_ANON_KEY');
final api = Supabase.instance.client;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (supabaseUrl.isEmpty || supabaseAnon.isEmpty) {
    runApp(const MaterialApp(home: Scaffold(body: Center(child: SelectableText(
        'Missing Supabase configuration. See README.md and use --dart-define.')))));
    return;
  }
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnon);
  runApp(const SellMateApp());
}

class I18n {
  static const Map<String, List<String>> labels = {
    'dashboard':['Dashboard','لوحة التحكم'],'products':['Products','المنتجات'],
    'orders':['Orders','الطلبات'],'customers':['Customers','الزبائن'],
    'reports':['Reports','التقارير'],'settings':['Settings','الإعدادات'],
    'welcome':['Welcome to SellMate','أهلاً بك في سيل ميت'],
    'login':['Sign in','تسجيل الدخول'],'signup':['Create account','إنشاء حساب'],
    'email':['Email','البريد الإلكتروني'],'password':['Password','كلمة المرور'],
    'name':['Name','الاسم'],'business':['Business name','اسم المتجر'],
    'currency':['Business currency','عملة المتجر'],'start':['Create business','إنشاء المتجر'],
    'logout':['Sign out','تسجيل الخروج'],'add_product':['Add product','إضافة منتج'],
    'sku':['SKU','رمز المنتج'],'cost':['Cost price','سعر التكلفة'],
    'price':['Selling price','سعر البيع'],'quantity':['Stock quantity','الكمية'],
    'threshold':['Low-stock threshold','حد المخزون المنخفض'],
    'save':['Save','حفظ'],'cancel':['Cancel','إلغاء'],
    'edit':['Edit','تعديل'],'delete':['Delete','حذف'],
    'create_order':['New order','طلب جديد'],'status':['Status','الحالة'],
    'customer':['Customer','الزبون'],'add_customer':['Add customer','إضافة زبون'],
    'phone':['Phone','الهاتف'],'address':['Address','العنوان'],
    'business_phone':['Business contact phone','رقم هاتف المتجر'],
    'edit_business_phone':['Edit business phone','تعديل هاتف المتجر'],
    'phone_help':['Saved to your private business profile.','محفوظ في ملف متجرك الخاص.'],
    'invalid_phone':['Enter a phone number starting with + and 8 to 15 digits.','أدخل رقم هاتف يبدأ بـ + ويتبعه ٨ إلى ١٥ رقماً.'],
    'amount':['Amount','المبلغ'],'description':['Description','الوصف'],
    'add_expense':['Add expense','إضافة مصروف'],
    'sales':['Delivered sales','المبيعات المسلّمة'],
    'profit':['Estimated profit','الربح التقديري'],
    'expenses':['Expenses','المصاريف'],
    'pending':['Pending','قيد الانتظار'],'confirmed':['Confirmed','مؤكد'],
    'shipped':['Shipped','تم الشحن'],'delivered':['Delivered','تم التسليم'],
    'cancelled':['Cancelled','ملغى'],
    'settings_lang':['Language','اللغة'],'none':['Nothing here yet','لا توجد بيانات بعد'],
    'select_product':['Choose product','اختر منتجاً'],
    'collect':['Cash collected','المبلغ المحصّل'],
    'save_order':['Create order','إنشاء الطلب'],
    'monthly':['This month','هذا الشهر'],
    'stock':['Low-stock products','المنتجات منخفضة المخزون'],
    'retry':['Retry','إعادة المحاولة'],
    'forgot_password':['Forgot password?','هل نسيت كلمة المرور؟'],
    'reset_email_sent':['If this address is registered, check your email for a reset link.','إذا كان البريد مسجلاً، تحقق من رسالة إعادة التعيين.'],
    'reset_password':['Send reset link','إرسال رابط إعادة التعيين'],
    'invalid_email':['Enter a valid email address.','أدخل بريداً إلكترونياً صحيحاً.'],
    'auth_switch_signup':['New here? Create an account','جديد هنا؟ أنشئ حساباً'],
    'auth_switch_login':['Already have an account? Sign in','لديك حساب؟ تسجيل الدخول'],
    'auth_validation':['Enter a valid email, a name and a password of at least 8 characters.','أدخل بريداً صحيحاً واسماً وكلمة مرور لا تقل عن ٨ أحرف.'],
    'confirm_email':['Confirm your email, then sign in.','أكد بريدك الإلكتروني، ثم سجل الدخول.'],
    'choose_currency':['One accounting currency per business. No automatic conversion.','عملة محاسبية واحدة لكل متجر، دون تحويل تلقائي.'],
    'refresh':['Refresh','تحديث'],'my_settings':['Account settings','إعدادات الحساب'],
    'account_email':['Account email','البريد الإلكتروني للحساب'],
    'base_currency':['Accounting currency','العملة المحاسبية'],
    'language':['Language','اللغة'],'plan':['Plan','الخطة'],
    'free_plan':['Free preview — billing not enabled','النسخة المجانية — الدفع غير مفعل'],
    'data_notice':['All business data is stored in your connected Supabase project.','تُحفظ بيانات المتجر في مشروع Supabase المتصل.'],
    'delete_product':['Delete this product?','حذف هذا المنتج؟'],
    'delete_product_info':['Products referenced by orders cannot be deleted.','لا يمكن حذف المنتجات المرتبطة بطلبات.'],
    'stock_label':['Stock','المخزون'], 'order_total':['Order total','إجمالي الطلب'],
    'walk_in':['Walk-in customer','زبون مباشر'],
    'add_products_first':['Add products before creating an order.','أضف منتجات قبل إنشاء طلب.'],
    'min_one_product':['Add at least one product.','أضف منتجاً واحداً على الأقل.'],
    'cost_note':['Estimates only. Excludes taxes and costs not entered.','تقديرات فقط، لا تشمل الضرائب والتكاليف غير المسجلة.'],
    'outstanding':['Outstanding — active orders','المبلغ المتبقي — الطلبات النشطة'],
    'all_time':['All time','كل الفترة'], 'this_month':['This month','هذا الشهر'],
    'last_30':['Last 30 days','آخر ٣٠ يوماً'], 'report_period':['Report period','فترة التقرير'],
    'report_note':['Profit is an estimate using delivered orders and recorded expenses in the selected period; not audited accounting.','الربح تقديري ويعتمد على الطلبات المسلّمة والمصاريف المسجلة خلال الفترة، وليس محاسبة مدققة.'],
    'search_products':['Search products or SKU','البحث عن منتج أو رمز'],
    'search_customers':['Search customers','البحث عن زبائن'],
    'cancel_delivery_title':['Cancel a delivered order?','إلغاء طلب تم تسليمه؟'],
    'cancel_delivery_info':['Stock will be restored. Review any money already collected.','ستُستعاد الكمية؛ راجع المبالغ التي تم تحصيلها.'],
    'keep':['Keep order','إبقاء الطلب'],
    'invalid_expense':['Enter a description and a positive amount.','أدخل وصفاً ومبلغاً أكبر من الصفر.'],
    'invalid_product':['Enter a name and valid nonnegative numbers.','أدخل اسماً وأرقاماً صحيحة غير سالبة.'],
    'save_success':['Saved successfully','تم الحفظ بنجاح'],
    'stock_rule':['Stock decreases on delivery. Totals are calculated securely on the server.','ينخفض المخزون عند التسليم. تُحسب المجاميع بأمان على الخادم.'],
    'date':['Date','التاريخ'], 'search':['Search','بحث'],
    'no_results':['No matching records','لا توجد نتائج مطابقة'],
    'new_password':['New password','كلمة المرور الجديدة'],
    'update_password':['Update password','تغيير كلمة المرور'],
    'password_updated':['Password updated. You can continue to SellMate.','تم تغيير كلمة المرور، يمكنك المتابعة.'],
    'recovery_title':['Reset your password','إعادة تعيين كلمة المرور'],
    'signin_error':['Could not complete sign-in.','تعذر تسجيل الدخول.'],
    'invalid_status':['Invalid status change.','تغيير حالة غير صالح'],

  };
  static String t(String key, bool ar) => labels[key]?[ar ? 1 : 0] ?? key;
}

class SellMateApp extends StatefulWidget {
  const SellMateApp({super.key});
  @override State<SellMateApp> createState() => _SellMateAppState();
}
class _SellMateAppState extends State<SellMateApp> {
  bool ar = false;
  @override Widget build(BuildContext context) => MaterialApp(
    title: 'SellMate', debugShowCheckedModeBanner: false,
    locale: Locale(ar ? 'ar' : 'en'),
    supportedLocales: const [Locale('en'),Locale('ar')],
    localizationsDelegates: const [GlobalMaterialLocalizations.delegate,GlobalWidgetsLocalizations.delegate,GlobalCupertinoLocalizations.delegate],
    theme: ThemeData(useMaterial3: true, scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: green, primary: navy, secondary: green, surface: Colors.white),
      appBarTheme: const AppBarTheme(backgroundColor: bg, centerTitle: false),
      inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14,vertical: 14)),
      elevatedButtonTheme: ElevatedButtonThemeData(style: ElevatedButton.styleFrom(
        backgroundColor: navy, foregroundColor: Colors.white, minimumSize: const Size.fromHeight(50),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))))),
    home: AuthGate(ar: ar, switchLanguage: () => setState(()=>ar=!ar)),
  );
}

void notice(BuildContext context, Object error) {
  if (!context.mounted) return;
  final msg = error is PostgrestException ? error.message : error is AuthException ? error.message : error.toString();
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
}
String money(num n, String currency) => '${currency == 'USD' ? r'$' : 'LBP '}${NumberFormat('#,##0.00').format(n)}';
num number(Object? value) => num.tryParse('$value') ?? 0;
String tt(String key, bool ar) => I18n.t(key,ar);

class AuthGate extends StatefulWidget {
  final bool ar; final VoidCallback switchLanguage;
  const AuthGate({super.key,required this.ar,required this.switchLanguage});
  @override State<AuthGate> createState()=>_AuthGateState();
}
class _AuthGateState extends State<AuthGate> {
  StreamSubscription<AuthState>? sub;
  bool recovering=false;
  @override void initState(){super.initState();sub=api.auth.onAuthStateChange.listen((state) {
    if(!mounted)return;
    setState(() {
      if(state.event==AuthChangeEvent.passwordRecovery)recovering=true;
      if(state.event==AuthChangeEvent.signedOut)recovering=false;
    });
  },onError:(Object e,StackTrace trace){if(mounted)notice(context,e);});}
  @override void dispose(){sub?.cancel();super.dispose();}
  @override Widget build(BuildContext context) => recovering
      ? RecoveryPage(ar:widget.ar,onComplete:()=>setState(()=>recovering=false))
      : api.auth.currentSession==null
      ? AuthPage(ar:widget.ar,switchLanguage:widget.switchLanguage)
      : BusinessGate(ar:widget.ar,switchLanguage:widget.switchLanguage);
}

class RecoveryPage extends StatefulWidget {
  final bool ar;
  final VoidCallback onComplete;
  const RecoveryPage({super.key,required this.ar,required this.onComplete});
  @override State<RecoveryPage> createState()=>_RecoveryPageState();
}
class _RecoveryPageState extends State<RecoveryPage> {
  final password=TextEditingController();
  bool busy=false;
  @override void dispose(){password.dispose();super.dispose();}
  Future<void> save() async {
    if(password.text.length<8){notice(context,tt('auth_validation',widget.ar));return;}
    setState(()=>busy=true);
    try {
      await api.auth.updateUser(UserAttributes(password:password.text));
      if(mounted){notice(context,tt('password_updated',widget.ar));widget.onComplete();}
    }catch(e){if(mounted)notice(context,e);}
    finally {if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(tt('recovery_title',widget.ar))),body:Center(child:ConstrainedBox(
    constraints:const BoxConstraints(maxWidth:440),child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[
      TextField(controller:password,obscureText:true,decoration:InputDecoration(labelText:tt('new_password',widget.ar))),
      const SizedBox(height:16),ElevatedButton(onPressed:busy?null:save,child:Text(tt('update_password',widget.ar)))
    ])))));
}

class AuthPage extends StatefulWidget {
  final bool ar; final VoidCallback switchLanguage;
  const AuthPage({super.key,required this.ar,required this.switchLanguage});
  @override State<AuthPage> createState()=>_AuthPageState();
}
class _AuthPageState extends State<AuthPage>{
  final email=TextEditingController(),password=TextEditingController(),name=TextEditingController();
  bool signup=false,busy=false;
  @override void dispose(){email.dispose();password.dispose();name.dispose();super.dispose();}
  Future<void> submit() async {
    if(email.text.trim().isEmpty||password.text.length<8||(signup&&name.text.trim().isEmpty)){
      notice(context, tt('auth_validation',widget.ar));return;}
    setState(()=>busy=true);
    try{
      if(signup){
        final r=await api.auth.signUp(email:email.text.trim(),password:password.text,
          data:{'full_name':name.text.trim()});
        if(r.session==null&&mounted)notice(context,tt('confirm_email',widget.ar));
      } else {
        await api.auth.signInWithPassword(email:email.text.trim(),password:password.text);
      }
    }catch(e){if(mounted)notice(context,e);}finally{if(mounted)setState(()=>busy=false);}
  }
  Future<void> resetPassword() async {
    final address=email.text.trim();
    if(!address.contains('@') || !address.contains('.')) {notice(context,tt('invalid_email',widget.ar));return;}
    try {
      await api.auth.resetPasswordForEmail(address);
      if(mounted)notice(context,tt('reset_email_sent',widget.ar));
    } catch(e) {if(mounted)notice(context,e);}
  }
  @override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(
    padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:440),child:Column(
    crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      Align(alignment:AlignmentDirectional.centerEnd,child:TextButton(onPressed:widget.switchLanguage,child:Text(widget.ar?'English':'العربية'))),
      const Icon(Icons.storefront_rounded,size:56,color:green),const SizedBox(height:12),
      const Text('SellMate',style:TextStyle(fontSize:38,fontWeight:FontWeight.w800,color:navy),textAlign:TextAlign.center),
      const SizedBox(height:5),Text(tt('welcome',widget.ar),textAlign:TextAlign.center),const SizedBox(height:32),
      if(signup)...[TextField(controller:name,textCapitalization:TextCapitalization.words,decoration:InputDecoration(labelText:tt('name',widget.ar))),const SizedBox(height:12)],
      TextField(controller:email,keyboardType:TextInputType.emailAddress,autocorrect:false,decoration:InputDecoration(labelText:tt('email',widget.ar))),const SizedBox(height:12),
      TextField(controller:password,obscureText:true,decoration:InputDecoration(labelText:tt('password',widget.ar))),const SizedBox(height:18),
      ElevatedButton(onPressed:busy?null:submit,child:Text(busy?'…':tt(signup?'signup':'login',widget.ar))),
      TextButton(onPressed:busy?null:()=>setState(()=>signup=!signup),child:Text(tt(signup?'auth_switch_login':'auth_switch_signup',widget.ar))),
      if(!signup)TextButton(onPressed:busy?null:resetPassword,child:Text(tt('forgot_password',widget.ar))),
    ]))))));
}

class BusinessGate extends StatefulWidget{
  final bool ar;final VoidCallback switchLanguage;
  const BusinessGate({super.key,required this.ar,required this.switchLanguage});
  @override State<BusinessGate> createState()=>_BusinessGateState();
}
class _BusinessGateState extends State<BusinessGate>{
  late Future<List<Map<String,dynamic>>> future;
  @override void initState(){super.initState();reload();}
  void reload()=>future=api.from('businesses').select().eq('owner_id',api.auth.currentUser!.id).limit(1);
  @override Widget build(BuildContext context)=>FutureBuilder<List<Map<String,dynamic>>>(future:future,builder:(context,s){
    if(s.hasError)return Scaffold(body:Center(child:Column(mainAxisSize:MainAxisSize.min,children:[Text('${s.error}'),TextButton(onPressed:()=>setState(reload),child:Text(tt('retry',widget.ar)))])));
    if(!s.hasData)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    if(s.data!.isEmpty)return SetupPage(ar:widget.ar,onCreated:()=>setState(reload));
    return HomePage(key:ValueKey(s.data!.first['id']),business:s.data!.first,ar:widget.ar,switchLanguage:widget.switchLanguage);
  });
}

class SetupPage extends StatefulWidget{
  final bool ar; final VoidCallback onCreated;
  const SetupPage({super.key,required this.ar,required this.onCreated});
  @override State<SetupPage> createState()=>_SetupPageState();
}
class _SetupPageState extends State<SetupPage>{
  final name=TextEditingController();
  final phone=TextEditingController(text:defaultBusinessPhone);
  String currency='USD';bool busy=false;
  @override void dispose(){name.dispose();phone.dispose();super.dispose();}
  Future<void> save()async{
    if(name.text.trim().isEmpty)return;
    if(!RegExp(r'^\+[1-9]\d{7,14}$').hasMatch(phone.text.trim())){notice(context,tt('invalid_phone',widget.ar));return;}
    setState(()=>busy=true);
    try{await api.from('businesses').insert({'owner_id':api.auth.currentUser!.id,'name':name.text.trim(),'currency':currency,'contact_phone':phone.text.trim()});widget.onCreated();}
    catch(e){if(mounted)notice(context,e);}finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('SellMate · Setup'),actions:[IconButton(onPressed:()=>api.auth.signOut(),icon:const Icon(Icons.logout))]),body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:440),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    const Icon(Icons.store_rounded,size:64,color:green),const SizedBox(height:24),
    Text(tt('business',widget.ar),style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),const SizedBox(height:12),
    TextField(controller:name,decoration:InputDecoration(labelText:tt('business',widget.ar))),const SizedBox(height:12),
    TextField(controller:phone,keyboardType:TextInputType.phone,decoration:InputDecoration(labelText:tt('business_phone',widget.ar))),const SizedBox(height:12),
    DropdownButtonFormField<String>(initialValue:currency,decoration:InputDecoration(labelText:tt('currency',widget.ar)),items:['USD','LBP'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>currency=v!)),const SizedBox(height:18),
    ElevatedButton(onPressed:busy?null:save,child:Text(tt('start',widget.ar))),
    const SizedBox(height:12),Text(tt('choose_currency',widget.ar),style:const TextStyle(fontSize:12)),
  ])))));
}
class HomePage extends StatefulWidget {
  final Map<String,dynamic> business;final bool ar;final VoidCallback switchLanguage;
  const HomePage({super.key,required this.business,required this.ar,required this.switchLanguage});
  @override State<HomePage> createState()=>_HomePageState();
}
class _HomePageState extends State<HomePage>{
  int tab=0;int refresh=0;
  void reload()=>setState(()=>refresh++);
  String get bid=>widget.business['id'] as String;
  String get cur=>widget.business['currency'] as String;
  @override Widget build(BuildContext context){
    final views=[DashboardView(bid:bid,cur:cur,ar:widget.ar,refresh:refresh),
      ProductsView(bid:bid,cur:cur,ar:widget.ar,refresh:refresh,reload:reload),
      OrdersView(bid:bid,cur:cur,ar:widget.ar,refresh:refresh,reload:reload),
      CustomersView(bid:bid,ar:widget.ar,refresh:refresh,reload:reload),
      ReportsView(bid:bid,cur:cur,ar:widget.ar,refresh:refresh,reload:reload),
      const SizedBox.shrink()];
    return Scaffold(
      appBar:AppBar(title:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(widget.business['name'] as String,style:const TextStyle(fontSize:19,fontWeight:FontWeight.w800)),
        const Text('SellMate',style:TextStyle(color:green,fontSize:11))]),
        actions:[IconButton(tooltip:tt('refresh',widget.ar),onPressed:reload,icon:const Icon(Icons.refresh)),
          PopupMenuButton<String>(icon:const Icon(Icons.settings_outlined),onSelected:(v)async{
          if(v=='language')widget.switchLanguage();
          if(v=='settings'&&context.mounted)await Navigator.push(context,MaterialPageRoute(builder:(_)=>AccountSettingsPage(business:widget.business,ar:widget.ar,switchLanguage:widget.switchLanguage)));
          if(v=='logout')await api.auth.signOut();
          },itemBuilder:(c)=>[
            PopupMenuItem(value:'language',child:Text('${tt('settings_lang',widget.ar)}: ${widget.ar?'English':'العربية'}')),
            PopupMenuItem(value:'settings',child:Text(tt('my_settings',widget.ar))),
            PopupMenuItem(value:'logout',child:Text(tt('logout',widget.ar)))])]),
      body:SafeArea(child:IndexedStack(index:tab,children:views.take(5).toList())),
      bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),
        labelBehavior:NavigationDestinationLabelBehavior.alwaysShow,
        destinations:[
          NavigationDestination(icon:const Icon(Icons.space_dashboard_outlined),label:tt('dashboard',widget.ar)),
          NavigationDestination(icon:const Icon(Icons.inventory_2_outlined),label:tt('products',widget.ar)),
          NavigationDestination(icon:const Icon(Icons.receipt_long_outlined),label:tt('orders',widget.ar)),
          NavigationDestination(icon:const Icon(Icons.people_outline),label:tt('customers',widget.ar)),
          NavigationDestination(icon:const Icon(Icons.bar_chart_outlined),label:tt('reports',widget.ar))]),
    );
  }
}


class AccountSettingsPage extends StatelessWidget {
  final Map<String,dynamic> business;
  final bool ar;
  final VoidCallback switchLanguage;
  const AccountSettingsPage({super.key,required this.business,required this.ar,required this.switchLanguage});
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:Text(tt('my_settings',ar))),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      boxCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        ListTile(leading:const Icon(Icons.store_outlined),title:Text('${business['name']}'),subtitle:Text('${tt('base_currency',ar)}: ${business['currency']}')),
        BusinessPhoneTile(business:business,ar:ar),
        ListTile(leading:const Icon(Icons.email_outlined),title:Text(tt('account_email',ar)),subtitle:Text(api.auth.currentUser?.email??'')),
        ListTile(leading:const Icon(Icons.translate_outlined),title:Text(tt('language',ar)),subtitle:Text(ar?'العربية':'English'),trailing:const Icon(Icons.swap_horiz),onTap:(){switchLanguage();Navigator.pop(context);}),
        ListTile(leading:const Icon(Icons.workspace_premium_outlined),title:Text(tt('plan',ar)),subtitle:Text(tt('free_plan',ar))),
      ])),
      const SizedBox(height:14),Text(tt('data_notice',ar),style:const TextStyle(color:Colors.blueGrey,fontSize:12)),
      const SizedBox(height:24),OutlinedButton.icon(onPressed:() async {await api.auth.signOut();if(context.mounted)Navigator.pop(context);},icon:const Icon(Icons.logout),label:Text(tt('logout',ar)))
    ]));
}

class BusinessPhoneTile extends StatefulWidget {
  final Map<String,dynamic> business;
  final bool ar;
  const BusinessPhoneTile({super.key,required this.business,required this.ar});
  @override State<BusinessPhoneTile> createState()=>_BusinessPhoneTileState();
}
class _BusinessPhoneTileState extends State<BusinessPhoneTile> {
  late String phone;
  @override void initState(){super.initState();phone='${widget.business['contact_phone']??''}';}
  Future<void> editPhone() async {
    final controller=TextEditingController(text:phone);
    final candidate=await showDialog<String>(context:context,builder:(dialogContext)=>AlertDialog(
      title:Text(tt('edit_business_phone',widget.ar)),
      content:TextField(controller:controller,keyboardType:TextInputType.phone,
        decoration:InputDecoration(labelText:tt('business_phone',widget.ar))),
      actions:[
        TextButton(onPressed:()=>Navigator.pop(dialogContext),child:Text(tt('cancel',widget.ar))),
        TextButton(onPressed:()=>Navigator.pop(dialogContext,controller.text.trim()),child:Text(tt('save',widget.ar))),
      ],
    ));
    // The dialog is closed before the controller is disposed.
    controller.dispose();
    if(!mounted||candidate==null)return;
    if(!RegExp(r'^\+[1-9]\d{7,14}$').hasMatch(candidate)){
      notice(context,tt('invalid_phone',widget.ar));return;
    }
    try {
      await api.from('businesses').update({'contact_phone':candidate}).eq('id',widget.business['id']);
      if(!mounted)return;
      widget.business['contact_phone']=candidate;
      setState(()=>phone=candidate);
      notice(context,tt('save_success',widget.ar));
    } catch(e) {if(mounted)notice(context,e);}
  }
  @override Widget build(BuildContext context)=>ListTile(
    leading:const Icon(Icons.phone_outlined),
    title:Text(tt('business_phone',widget.ar)),subtitle:Text(phone),
    trailing:const Icon(Icons.edit_outlined),onTap:editPhone,
  );
}

Widget boxCard({required Widget child})=>Card(elevation:0,color:Colors.white,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(16)),child:Padding(padding:const EdgeInsets.all(16),child:child));
Widget empty(String label)=>Center(child:Padding(padding:const EdgeInsets.all(32),child:Text(label,style:const TextStyle(color:Colors.blueGrey))));
Widget sectionTitle(String label)=>Padding(padding:const EdgeInsets.only(bottom:12,top:12),child:Text(label,style:const TextStyle(fontSize:19,fontWeight:FontWeight.w700,color:navy)));
Widget metric(String title,String value,IconData icon)=>boxCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:green),const SizedBox(height:12),Text(title,style:const TextStyle(color:Colors.blueGrey,fontSize:12)),const SizedBox(height:6),Text(value,style:const TextStyle(fontSize:19,fontWeight:FontWeight.bold,color:navy))]));

class DashboardView extends StatelessWidget{
  final String bid,cur;final bool ar;final int refresh;
  const DashboardView({super.key,required this.bid,required this.cur,required this.ar,required this.refresh});
  Future<List<dynamic>> load()async=>Future.wait([
    api.from('products').select('id,name,quantity,low_stock_threshold').eq('business_id',bid),
    api.from('orders').select('id,status,total,cost_total,collected_amount').eq('business_id',bid),
    api.from('expenses').select('amount').eq('business_id',bid),
  ]);
  @override Widget build(BuildContext context)=>FutureBuilder<List<dynamic>>(key:ValueKey(refresh),future:load(),builder:(c,s){
    if(s.hasError)return empty('${s.error}');if(!s.hasData)return const Center(child:CircularProgressIndicator());
    final products=List<Map<String,dynamic>>.from(s.data![0]);
    final orders=List<Map<String,dynamic>>.from(s.data![1]);
    final expenses=List<Map<String,dynamic>>.from(s.data![2]);
    final delivered=orders.where((o)=>o['status']=='delivered');
    final sales=delivered.fold<num>(0,(a,o)=>a+number(o['total']));
    final cost=delivered.fold<num>(0,(a,o)=>a+number(o['cost_total']));
    final exp=expenses.fold<num>(0,(a,o)=>a+number(o['amount']));
    final cash=orders.where((o)=>o['status']!='cancelled').fold<num>(0,(a,o)=>a+number(o['collected_amount']));
    final low=products.where((p)=>number(p['quantity'])<=number(p['low_stock_threshold'])).toList();
    return RefreshIndicator(onRefresh:()async{(context as Element).markNeedsBuild();},child:ListView(padding:const EdgeInsets.all(16),children:[
      sectionTitle(tt('dashboard',ar)),
      LayoutBuilder(builder:(c,k)=>GridView.count(crossAxisCount:k.maxWidth>540?4:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),childAspectRatio:k.maxWidth>540?1.7:1.35,children:[
        metric(tt('sales',ar),money(sales,cur),Icons.trending_up),
        metric(tt('profit',ar),money(sales-cost-exp,cur),Icons.savings_outlined),
        metric(tt('orders',ar),'${orders.length}',Icons.receipt_long_outlined),
        metric(tt('collect',ar),money(cash,cur),Icons.payments_outlined),
      ])),
      sectionTitle(tt('stock',ar)),
      if(low.isEmpty)boxCard(child:Text(tt('none',ar)))
      else ...low.take(5).map((p)=>boxCard(child:Row(children:[const Icon(Icons.warning_amber,color:Colors.orange),const SizedBox(width:12),Expanded(child:Text('${p['name']}')),Text('${p['quantity']}')]))),
      const SizedBox(height:16),Text(tt('cost_note',ar),style:const TextStyle(color:Colors.blueGrey,fontSize:12)),
    ]));
  });
}

class ProductsView extends StatelessWidget{
  final String bid,cur;final bool ar;final int refresh;final VoidCallback reload;
  const ProductsView({super.key,required this.bid,required this.cur,required this.ar,required this.refresh,required this.reload});
  Future<List<Map<String,dynamic>>> load()=>api.from('products').select().eq('business_id',bid).order('created_at',ascending:false);
  @override Widget build(BuildContext context)=>FutureBuilder<List<Map<String,dynamic>>>(key:ValueKey(refresh),future:load(),builder:(c,s){
    return ListView(padding:const EdgeInsets.all(16),children:[
      Row(children:[Expanded(child:sectionTitle(tt('products',ar))),FilledButton.icon(
        onPressed:()=>openEditor(context),icon:const Icon(Icons.add),label:Text(tt('add_product',ar)))]),
      if(s.hasError)Text('${s.error}') else if(!s.hasData)const Center(child:CircularProgressIndicator())
      else if(s.data!.isEmpty)empty(tt('none',ar))
      else ...s.data!.map((p)=>boxCard(child:Row(children:[
        Container(width:44,height:44,decoration:BoxDecoration(color:bg,borderRadius:BorderRadius.circular(10)),child:const Icon(Icons.inventory_2_outlined,color:navy)),
        const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${p['name']}',style:const TextStyle(fontWeight:FontWeight.w700)),Text('Stock: ${p['quantity']} · ${p['sku']??'—'}',style:const TextStyle(fontSize:12,color:Colors.blueGrey))])),
        Column(crossAxisAlignment:CrossAxisAlignment.end,children:[Text(money(number(p['selling_price']),cur),style:const TextStyle(fontWeight:FontWeight.bold)),IconButton(onPressed:()=>openEditor(context,product:p),icon:const Icon(Icons.edit_outlined,size:20))]),
      ]))),
    ]);
  });
  void openEditor(BuildContext context,{Map<String,dynamic>? product})async{
    final success=await showModalBottomSheet<bool>(context:context,isScrollControlled:true,showDragHandle:true,builder:(c)=>ProductEditor(bid:bid,cur:cur,ar:ar,product:product));
    if(success==true)reload();
  }
}

class ProductEditor extends StatefulWidget{
  final String bid,cur;final bool ar;final Map<String,dynamic>? product;
  const ProductEditor({super.key,required this.bid,required this.cur,required this.ar,this.product});
  @override State<ProductEditor> createState()=>_ProductEditorState();
}
class _ProductEditorState extends State<ProductEditor>{
  late final TextEditingController name=TextEditingController(text:'${widget.product?['name']??''}');
  late final TextEditingController sku=TextEditingController(text:'${widget.product?['sku']??''}');
  late final TextEditingController cost=TextEditingController(text:'${widget.product?['cost_price']??'0'}');
  late final TextEditingController price=TextEditingController(text:'${widget.product?['selling_price']??''}');
  late final TextEditingController qty=TextEditingController(text:'${widget.product?['quantity']??'0'}');
  late final TextEditingController threshold=TextEditingController(text:'${widget.product?['low_stock_threshold']??5}');
  bool busy=false;
  @override void dispose(){for(final t in [name,sku,cost,price,qty,threshold]){t.dispose();}super.dispose();}
  Future<void> save()async{
    final c=num.tryParse(cost.text),p=num.tryParse(price.text),q=int.tryParse(qty.text),t=int.tryParse(threshold.text);
    if(name.text.trim().isEmpty||c==null||p==null||q==null||t==null||c<0||p<0||q<0||t<0){notice(context,tt('invalid_product',widget.ar));return;}
    setState(()=>busy=true);
    try{
      final data={'name':name.text.trim(),'sku':sku.text.trim().isEmpty?null:sku.text.trim(),
        'cost_price':c,'selling_price':p,'quantity':q,'low_stock_threshold':t};
      if(widget.product==null){await api.from('products').insert({...data,'business_id':widget.bid});}
      else{await api.from('products').update(data).eq('id',widget.product!['id']).eq('business_id',widget.bid);}
      if(mounted)Navigator.pop(context,true);
    }catch(e){if(mounted)notice(context,e);}finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context)=>Padding(padding:EdgeInsets.fromLTRB(20,0,20,MediaQuery.viewInsetsOf(context).bottom+20),child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    sectionTitle(widget.product==null?tt('add_product',widget.ar):tt('edit',widget.ar)),
    TextField(controller:name,decoration:InputDecoration(labelText:tt('name',widget.ar))),const SizedBox(height:10),
    TextField(controller:sku,decoration:InputDecoration(labelText:tt('sku',widget.ar))),const SizedBox(height:10),
    Row(children:[Expanded(child:decimalField(cost,tt('cost',widget.ar))),const SizedBox(width:10),Expanded(child:decimalField(price,tt('price',widget.ar)))]),const SizedBox(height:10),
    Row(children:[Expanded(child:intField(qty,tt('quantity',widget.ar))),const SizedBox(width:10),Expanded(child:intField(threshold,tt('threshold',widget.ar)))]),const SizedBox(height:18),
    ElevatedButton(onPressed:busy?null:save,child:Text(tt('save',widget.ar))),const SizedBox(height:10),
    if(widget.product!=null)TextButton.icon(onPressed:busy?null:()async{
      final confirm=await showDialog<bool>(context:context,builder:(dialog)=>AlertDialog(title:Text(tt('delete_product',widget.ar)),content:Text(tt('delete_product_info',widget.ar)),actions:[
        TextButton(onPressed:()=>Navigator.pop(dialog,false),child:Text(tt('cancel',widget.ar))),
        TextButton(onPressed:()=>Navigator.pop(dialog,true),child:Text(tt('delete',widget.ar)))
      ]));
      if(confirm!=true)return;
      try{await api.from('products').delete().eq('id',widget.product!['id']).eq('business_id',widget.bid);if(mounted)Navigator.pop(context,true);}catch(e){if(mounted)notice(context,e);}
    },icon:const Icon(Icons.delete_outline,color:Colors.red),label:Text(tt('delete',widget.ar),style:const TextStyle(color:Colors.red))),
  ])));
}
Widget decimalField(TextEditingController c,String label)=>TextField(controller:c,keyboardType:const TextInputType.numberWithOptions(decimal:true),inputFormatters:[FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],decoration:InputDecoration(labelText:label));
Widget intField(TextEditingController c,String label)=>TextField(controller:c,keyboardType:TextInputType.number,inputFormatters:[FilteringTextInputFormatter.digitsOnly],decoration:InputDecoration(labelText:label));
class CustomersView extends StatelessWidget{
  final String bid;final bool ar;final int refresh;final VoidCallback reload;
  const CustomersView({super.key,required this.bid,required this.ar,required this.refresh,required this.reload});
  @override Widget build(BuildContext context)=>FutureBuilder<List<Map<String,dynamic>>>(
    key:ValueKey(refresh),future:api.from('customers').select().eq('business_id',bid).order('created_at',ascending:false),
    builder:(c,s)=>ListView(padding:const EdgeInsets.all(16),children:[
      Row(children:[Expanded(child:sectionTitle(tt('customers',ar))),FilledButton.icon(onPressed:()=>openEditor(context),icon:const Icon(Icons.person_add_alt),label:Text(tt('add_customer',ar)))]),
      if(s.hasError)Text('${s.error}')else if(!s.hasData)const Center(child:CircularProgressIndicator())
      else if(s.data!.isEmpty)empty(tt('none',ar))else ...s.data!.map((v)=>boxCard(child:ListTile(contentPadding:EdgeInsets.zero,
        title:Text('${v['name']}'),subtitle:Text('${v['phone']??''}\n${v['address']??''}'),isThreeLine:true,
        trailing:IconButton(icon:const Icon(Icons.edit_outlined),onPressed:()=>openEditor(context,customer:v))))),
    ]));
  void openEditor(BuildContext context,{Map<String,dynamic>? customer})async{
    final success=await showModalBottomSheet<bool>(context:context,isScrollControlled:true,showDragHandle:true,
      builder:(c)=>CustomerEditor(bid:bid,ar:ar,customer:customer));if(success==true)reload();
  }
}
class CustomerEditor extends StatefulWidget{
  final String bid;final bool ar;final Map<String,dynamic>? customer;
  const CustomerEditor({super.key,required this.bid,required this.ar,this.customer});
  @override State<CustomerEditor> createState()=>_CustomerEditorState();
}
class _CustomerEditorState extends State<CustomerEditor>{
  late final name=TextEditingController(text:'${widget.customer?['name']??''}');
  late final phone=TextEditingController(text:'${widget.customer?['phone']??''}');
  late final address=TextEditingController(text:'${widget.customer?['address']??''}');bool busy=false;
  @override void dispose(){name.dispose();phone.dispose();address.dispose();super.dispose();}
  Future<void> save()async{if(name.text.trim().isEmpty)return;setState(()=>busy=true);
    try{final data={'name':name.text.trim(),'phone':phone.text.trim(),'address':address.text.trim()};
      if(widget.customer==null){await api.from('customers').insert({...data,'business_id':widget.bid});}
      else{await api.from('customers').update(data).eq('id',widget.customer!['id']).eq('business_id',widget.bid);}
      if(mounted)Navigator.pop(context,true);
    }catch(e){if(mounted)notice(context,e);}finally{if(mounted)setState(()=>busy=false);}}
  @override Widget build(BuildContext context)=>Padding(padding:EdgeInsets.fromLTRB(20,0,20,MediaQuery.viewInsetsOf(context).bottom+24),
    child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      sectionTitle(tt('customer',widget.ar)),TextField(controller:name,decoration:InputDecoration(labelText:tt('name',widget.ar))),const SizedBox(height:10),
      TextField(controller:phone,keyboardType:TextInputType.phone,decoration:InputDecoration(labelText:tt('phone',widget.ar))),const SizedBox(height:10),
      TextField(controller:address,decoration:InputDecoration(labelText:tt('address',widget.ar))),const SizedBox(height:18),
      ElevatedButton(onPressed:busy?null:save,child:Text(tt('save',widget.ar))),
    ])));
}

class OrdersView extends StatelessWidget{
  final String bid,cur;final bool ar;final int refresh;final VoidCallback reload;
  const OrdersView({super.key,required this.bid,required this.cur,required this.ar,required this.refresh,required this.reload});
  Future<List<Map<String,dynamic>>> load()=>api.from('orders').select('id,status,total,cost_total,collected_amount,created_at,customers(name)').eq('business_id',bid).order('created_at',ascending:false);
  @override Widget build(BuildContext context)=>FutureBuilder<List<Map<String,dynamic>>>(key:ValueKey(refresh),future:load(),builder:(c,s)=>ListView(padding:const EdgeInsets.all(16),children:[
    Row(children:[Expanded(child:sectionTitle(tt('orders',ar))),FilledButton.icon(icon:const Icon(Icons.add),label:Text(tt('create_order',ar)),onPressed:()=>newOrder(context))]),
    if(s.hasError)Text('${s.error}')else if(!s.hasData)const Center(child:CircularProgressIndicator())
    else if(s.data!.isEmpty)empty(tt('none',ar))
    else ...s.data!.map((o)=>boxCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[Expanded(child:Text('Order ${('${o['id']}').substring(0,8).toUpperCase()}',style:const TextStyle(fontWeight:FontWeight.w700))),Text(money(number(o['total']),cur),style:const TextStyle(fontWeight:FontWeight.bold))]),
      const SizedBox(height:5),Text('${(o['customers'] as Map?)?['name']??'Walk-in'} · ${('${o['created_at']}').split('T').first}',style:const TextStyle(fontSize:12,color:Colors.blueGrey)),
      const SizedBox(height:8),Row(children:[Expanded(child:DropdownButton<String>(value:o['status'] as String,isExpanded:true,
        items:['pending','confirmed','shipped','delivered','cancelled'].map((v)=>DropdownMenuItem(value:v,child:Text(tt(v,ar)))).toList(),
        onChanged:o['status']=='cancelled'?null:(v)async{
          if(v==null||v==o['status'])return;
          if(v=='cancelled'&&o['status']=='delivered'){
            final yes=await showDialog<bool>(context:context,builder:(d)=>AlertDialog(title:Text(tt('cancel_delivery_title',ar)),content:Text(tt('cancel_delivery_info',ar)),actions:[TextButton(onPressed:()=>Navigator.pop(d,false),child:Text(tt('keep',ar))),TextButton(onPressed:()=>Navigator.pop(d,true),child:Text(tt('cancel',ar)))]));
            if(yes!=true)return;
          }
          try{await api.rpc('change_order_status',params:{'p_order':o['id'],'p_status':v});reload();}catch(e){if(context.mounted)notice(context,e);}
        })),const SizedBox(width:10),TextButton(onPressed:()=>collect(context,o),child:Text('${tt('collect',ar)}: ${money(number(o['collected_amount']),cur)}',style:const TextStyle(fontSize:11)))]),
    ]))),
  ]));
  void newOrder(BuildContext context)async{
    final success=await Navigator.of(context).push<bool>(MaterialPageRoute(builder:(c)=>NewOrderPage(bid:bid,cur:cur,ar:ar)));
    if(success==true)reload();
  }
  Future<void> collect(BuildContext context,Map<String,dynamic> order)async{
    final controller=TextEditingController(text:'${order['collected_amount']}');
    final result=await showDialog<num>(context:context,builder:(c)=>AlertDialog(title:Text(tt('collect',ar)),content:decimalField(controller,'$cur amount'),actions:[
      TextButton(onPressed:()=>Navigator.pop(c),child:Text(tt('cancel',ar))),
      TextButton(onPressed:()=>Navigator.pop(c,num.tryParse(controller.text)),child:Text(tt('save',ar))) ]));
    controller.dispose();if(result==null)return;
    try{await api.rpc('set_order_collection',params:{'p_order':order['id'],'p_amount':result});reload();}catch(e){if(context.mounted)notice(context,e);}
  }
}

class OrderLine {
  String productId;int quantity;
  OrderLine(this.productId,this.quantity);
}
class NewOrderPage extends StatefulWidget{
  final String bid,cur;final bool ar;
  const NewOrderPage({super.key,required this.bid,required this.cur,required this.ar});
  @override State<NewOrderPage> createState()=>_NewOrderPageState();
}
class _NewOrderPageState extends State<NewOrderPage>{
  late final Future<List<dynamic>> data=Future.wait([
    api.from('products').select('id,name,selling_price,quantity').eq('business_id',widget.bid).order('name'),
    api.from('customers').select('id,name').eq('business_id',widget.bid).order('name')]);
  String? customer;final lines=<OrderLine>[];bool busy=false;
  Future<void> save(List<Map<String,dynamic>> products)async{
    if(lines.isEmpty){notice(context,tt('min_one_product',widget.ar));return;}
    setState(()=>busy=true);
    try{
      await api.rpc('create_order',params:{'p_business':widget.bid,'p_customer':customer,
        'p_items':lines.map((l)=>{'product_id':l.productId,'quantity':l.quantity}).toList()});
      if(mounted)Navigator.pop(context,true);
    }catch(e){if(mounted)notice(context,e);}finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(tt('create_order',widget.ar))),body:FutureBuilder<List<dynamic>>(future:data,builder:(c,s){
    if(s.hasError)return empty('${s.error}');if(!s.hasData)return const Center(child:CircularProgressIndicator());
    final products=List<Map<String,dynamic>>.from(s.data![0]);
    final customers=List<Map<String,dynamic>>.from(s.data![1]);
    final total=lines.fold<num>(0,(sum,l){final p=products.firstWhere((p)=>p['id']==l.productId);return sum+number(p['selling_price'])*l.quantity;});
    return ListView(padding:const EdgeInsets.all(16),children:[
      sectionTitle(tt('customer',widget.ar)),
      DropdownButtonFormField<String>(initialValue:customer,decoration:InputDecoration(labelText:tt('customer',widget.ar)),
        items:[DropdownMenuItem(value:null,child:Text(tt('walk_in',widget.ar))),...customers.map((p)=>DropdownMenuItem(value:p['id'] as String,child:Text('${p['name']}')))],
        onChanged:(v)=>setState(()=>customer=v)),
      sectionTitle(tt('products',widget.ar)),
      if(products.isEmpty)Text(tt('add_products_first',widget.ar)),
      ...lines.asMap().entries.map((entry){final idx=entry.key,l=entry.value;final p=products.firstWhere((p)=>p['id']==l.productId);return boxCard(child:Row(children:[
        Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${p['name']}',style:const TextStyle(fontWeight:FontWeight.bold)),Text(money(number(p['selling_price'])*l.quantity,widget.cur))])),
        IconButton(onPressed:()=>setState((){if(l.quantity>1)l.quantity--;}),icon:const Icon(Icons.remove_circle_outline)),Text('${l.quantity}'),
        IconButton(onPressed:()=>setState(()=>l.quantity++),icon:const Icon(Icons.add_circle_outline)),
        IconButton(onPressed:()=>setState(()=>lines.removeAt(idx)),icon:const Icon(Icons.close,color:Colors.red)),
      ]));}),
      if(products.isNotEmpty)OutlinedButton.icon(onPressed:(){showModalBottomSheet(context:context,builder:(c)=>SafeArea(child:ListView(shrinkWrap:true,children:products.map((p)=>ListTile(title:Text('${p['name']}'),subtitle:Text('${p['quantity']} in stock'),trailing:Text(money(number(p['selling_price']),widget.cur)),onTap:(){setState((){final existing=lines.where((l)=>l.productId==p['id']);if(existing.isEmpty){lines.add(OrderLine(p['id'] as String,1));}else{existing.first.quantity++;}});Navigator.pop(c);})).toList())));},icon:const Icon(Icons.add),label:Text(tt('select_product',widget.ar))),
      const SizedBox(height:18),boxCard(child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(tt('order_total',widget.ar)),Text(money(total,widget.cur),style:const TextStyle(fontWeight:FontWeight.bold,fontSize:20))])),const SizedBox(height:14),
      ElevatedButton(onPressed:busy?null:()=>save(products),child:Text(tt('save_order',widget.ar))),
      const SizedBox(height:12),Text(tt('stock_rule',widget.ar),style:const TextStyle(fontSize:12,color:Colors.blueGrey)),
    ]);
  }));
}

class ReportsView extends StatefulWidget{
  final String bid,cur;final bool ar;final int refresh;final VoidCallback reload;
  const ReportsView({super.key,required this.bid,required this.cur,required this.ar,required this.refresh,required this.reload});
  @override State<ReportsView> createState()=>_ReportsViewState();
}
class _ReportsViewState extends State<ReportsView> {
  String period='all_time';
  String get bid=>widget.bid;
  String get cur=>widget.cur;
  bool get ar=>widget.ar;
  int get refresh=>widget.refresh;
  VoidCallback get reload=>widget.reload;
  bool inPeriod(String? date) {
    if(period=='all_time')return true;
    final parsed=DateTime.tryParse(date??'');
    if(parsed==null)return false;
    final now=DateTime.now();
    if(period=='this_month')return parsed.year==now.year&&parsed.month==now.month;
    return !parsed.isBefore(now.subtract(const Duration(days:30)));
  }
  Future<List<dynamic>> load()async=>Future.wait([
    api.from('orders').select('total,cost_total,collected_amount,status,created_at,delivered_at').eq('business_id',bid),
    api.from('expenses').select().eq('business_id',bid).order('occurred_on',ascending:false),
  ]);
  @override Widget build(BuildContext context)=>FutureBuilder<List<dynamic>>(key:ValueKey(refresh),future:load(),builder:(c,s){
    if(s.hasError)return empty('${s.error}');if(!s.hasData)return const Center(child:CircularProgressIndicator());
    final orders=List<Map<String,dynamic>>.from(s.data![0]);final expenses=List<Map<String,dynamic>>.from(s.data![1]);
    final delivered=orders.where((o)=>o['status']=='delivered'&&inPeriod(o['delivered_at'] as String?));
    final sales=delivered.fold<num>(0,(a,v)=>a+number(v['total']));
    final cost=delivered.fold<num>(0,(a,v)=>a+number(v['cost_total']));
    final exp=expenses.where((e)=>inPeriod(e['occurred_on'] as String?)).fold<num>(0,(a,v)=>a+number(v['amount']));
    final outstanding=orders.where((o)=>o['status']!='cancelled'&&inPeriod(o['created_at'] as String?)).fold<num>(0,(a,v)=>a+number(v['total'])-number(v['collected_amount']));
    return ListView(padding:const EdgeInsets.all(16),children:[
      sectionTitle(tt('reports',ar)),
      DropdownButtonFormField<String>(initialValue:period,decoration:InputDecoration(labelText:tt('report_period',ar)),items:['all_time','this_month','last_30'].map((v)=>DropdownMenuItem(value:v,child:Text(tt(v,ar)))).toList(),onChanged:(v){if(v!=null)setState(()=>period=v);}),
      const SizedBox(height:12),metric(tt('sales',ar),money(sales,cur),Icons.payments_outlined),
      metric(tt('expenses',ar),money(exp,cur),Icons.money_off_outlined),
      metric(tt('profit',ar),money(sales-cost-exp,cur),Icons.show_chart),
      metric(tt('outstanding',ar),money(outstanding,cur),Icons.account_balance_wallet_outlined),
      Row(children:[Expanded(child:sectionTitle(tt('expenses',ar))),FilledButton.icon(onPressed:()=>addExpense(context),icon:const Icon(Icons.add),label:Text(tt('add_expense',ar)))]),
      if(expenses.where((e)=>inPeriod(e['occurred_on'] as String?)).isEmpty)empty(tt('none',ar))else ...expenses.where((e)=>inPeriod(e['occurred_on'] as String?)).take(30).map((e)=>boxCard(child:Row(children:[Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${e['description']}',style:const TextStyle(fontWeight:FontWeight.w600)),Text('${e['occurred_on']}',style:const TextStyle(fontSize:12,color:Colors.blueGrey))])),Text(money(number(e['amount']),cur))]))),
      const SizedBox(height:18),Text(tt('report_note',ar),style:const TextStyle(fontSize:12,color:Colors.blueGrey)),
    ]);
  });
  Future<void> addExpense(BuildContext context)async{
    final desc=TextEditingController(),amt=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:Text(tt('add_expense',ar)),content:Column(mainAxisSize:MainAxisSize.min,children:[
      TextField(controller:desc,decoration:InputDecoration(labelText:tt('description',ar))),const SizedBox(height:12),decimalField(amt,tt('amount',ar)),
    ]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:Text(tt('cancel',ar))),TextButton(onPressed:()=>Navigator.pop(c,true),child:Text(tt('save',ar)))]));
    if(ok==true){final amount=num.tryParse(amt.text);if(desc.text.trim().isEmpty||amount==null||amount<=0){if(context.mounted)notice(context,tt('invalid_expense',ar));}
      else{try{await api.from('expenses').insert({'business_id':bid,'description':desc.text.trim(),'amount':amount});reload();}catch(e){if(context.mounted)notice(context,e);}}}
    desc.dispose();amt.dispose();
  }
}
