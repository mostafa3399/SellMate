#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$(uname -s)" != "Darwin" ]]; then
  echo 'Error: iPhone builds require macOS with Xcode.' >&2
  exit 1
fi
if ! command -v flutter >/dev/null 2>&1; then
  echo 'Error: Flutter SDK is not installed or is not in PATH.' >&2
  exit 1
fi
if ! command -v xcodebuild >/dev/null 2>&1; then
  echo 'Error: Install Xcode and select its command line tools.' >&2
  exit 1
fi
flutter create --platforms=ios --org com.sellmate .
flutter pub get
flutter analyze
flutter test
flutter build ios --simulator --debug
printf '\nUnsigned iOS Simulator app: build/ios/iphonesimulator/Runner.app\n'
printf 'This cannot be installed directly on a physical iPhone. See docs/IOS_BUILD_AND_TEST.md.\n'
