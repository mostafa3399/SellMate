"""Source-only static smoke checks. Does not replace flutter analyze/test."""
from pathlib import Path
import re
root=Path(__file__).resolve().parent
src=(root/'lib/main.dart').read_text()
sql=(root/'supabase/schema.sql').read_text()
# strip Dart strings and comments, then check balanced punctuation
out=[];i=0
while i<len(src):
 c=src[i]
 if src.startswith('//',i):
  e=src.find('\n',i);i=len(src) if e<0 else e;continue
 if src.startswith('/*',i):
  e=src.find('*/',i+2);assert e>=0;i=e+2;continue
 if c in ('"',"'"):
  quote=c;i+=1
  while i<len(src):
   if src[i]=='\\':i+=2;continue
   if src[i]==quote:i+=1;break
   i+=1
  else:raise AssertionError('unterminated string')
  out.append(' ');continue
 out.append(c);i+=1
stack=[]
pairs={')':'(',']':'[','}':'{'}
for i,c in enumerate(''.join(out)):
 if c in '([{':stack.append((c,i))
 elif c in ')]}':
  assert stack and stack[-1][0]==pairs[c],f'unbalanced {c} at {i}, prior {stack[-1] if stack else None}'
  stack.pop()
assert not stack,f'unclosed braces: {stack[-5:]}'
keys=set(re.findall(r"'([^']+)'\s*:\s*\[\s*'",src))
used=set(re.findall(r"tt\('([^']+)'",src))
assert not used-keys,f'unknown labels: {used-keys}'
for label in ['auth_switch_signup','auth_switch_login','recovery_title','report_period','save_order']:
 assert label in keys
for table in ['profiles','businesses','products','customers','orders','order_items','inventory_movements','expenses']:
 assert f'create table public.{table}' in sql
 assert 'enable row level security' in sql
assert "const defaultBusinessPhone = '+96179162328'" in src
assert "'contact_phone':phone.text.trim()" in src
assert "BusinessPhoneTile(business:business,ar:ar)" in src
assert 'contact_phone text' in sql
assert (root/'supabase/migrations/20261103_add_business_contact_phone.sql').exists()
for name in ['create_order','change_order_status','set_order_collection']:
 assert f'function public.{name}' in sql
for f in ['docs/RELEASE_GATE.md','docs/SETUP_AND_TEST.md','docs/QA_TEST_MATRIX.md','docs/PRIVACY_POLICY_DRAFT.md']:
 assert (root/f).is_file()
print('PASS: balanced Dart delimiters, label references, SQL tables/RPC and docs present.')
print('NOT TESTED: Dart/Flutter compilation, Supabase execution, device builds and payments.')
