# SellMate — Flutter + Supabase source (v0.4.0 development source)

A real cross-platform Flutter application codebase for Lebanon-first business management. English/Arabic navigation, Supabase email-password auth, one business per account, editable business contact number, products/stock, customer records, orders, cash collection, expenses and basic financial reporting.

**Status**: Updated development source; no Supabase project connected, no Android/iOS builds generated, no SDK build/test run, no app-store submission, no subscriptions. **Not production-ready**. It is NOT a FlutterFlow project. The direct Flutter route was chosen to create a portable source-code deliverable without access to your FlutterFlow account.

## Setup (Windows or Mac)

1. Install the Flutter SDK, Android Studio/Android SDK, and (on Mac for iOS) Xcode. Verify: `flutter doctor`.
2. Extract this archive into a folder named `SellMate`.
3. Open a terminal *inside this folder* and run `flutter create --platforms=android,ios .` to create generated native project folders (not included). If using Windows, iOS build requires a Mac later. This should preserve `lib/main.dart` and `pubspec.yaml`.
4. Run `flutter pub get`.
5. Create your own Supabase project at https://supabase.com/dashboard. In **SQL Editor**, run `supabase/schema.sql` once against a fresh project. Make sure there are no conflicting tables from earlier experiments. If you already executed earlier SellMate SQL, use a new project or plan a migration; do not blindly rerun.
6. Supabase > Project Settings > API (or API Keys): copy **Project URL** and the **publishable** (or legacy `anon`) key. Do not use `service_role` or secret keys in the mobile app.
7. Supabase > Authentication > Providers: enable Email. Keep **Confirm Email** enabled. In production, configure an SMTP provider and email templates; initial default email delivery has limitations.
8. Run (replace placeholders with your own values; these keys are non-secret client keys):

   ```bash
   flutter run --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_PUBLISHABLE_OR_ANON_KEY
   ```

9. On a Mac, select an iOS simulator or attached iPhone for iOS debugging and configure signing with Xcode. On Windows, run on Android first; you can also run on web with `flutter run -d chrome ...` for development, though native deployment still requires setup.
10. Run `flutter analyze` and `flutter test` in your own SDK environment. Fix any SDK/toolchain compatibility warnings before release. Testing was not possible in the source-generating environment because Flutter/Dart are not installed.

## App functionality

| Area | Implemented in source | Caveats |
|---|---|---|
| Auth | Email sign-up/login, email confirmation flow message, logout, session restore via Supabase SDK | Recovery-screen included but native deep-link setup and testing needed; add rate limiting and account deletion UX |
| Business | Create business, editable contact phone (+96179162328 initially), USD or LBP base accounting currency | One business per owner; no exchange conversion. Business contact is not a public directory listing |
| Products | Add/edit with SKU, cost, price, quantity, low-stock | Product deletion added (referenced products cannot be deleted); no images, variants, barcodes, CSV import |
| Inventory | Current stock, movement log in database | Manual stock editor writes adjustment movement; robust audit/roles need review |
| Customers | Add/edit customer, phone, address | No export/search yet |
| Orders | Create order with products, status change, server-derived totals, delivered stock decrement, cancellation restock, cash collection | No delivery integrations, discount/tax/returns, partial shipment |
| Reports | Revenue from delivered orders, cost snapshot, expenses, outstanding balance, rough profit | All-time/current-month/last-30-days estimates; no accounting ledger, VAT, refunds or exchange rates |
| English/Arabic | Bilingual main navigation/forms and RTL through locale | Additional UI strings translated; some provider/error strings remain untranslated; requires device review |
| Subscription | NOT IMPLEMENTED | Requires payment integration, subscription entitlement DB and store compliance |

## Important business logic

- All order totals are calculated on the **server** in `public.create_order`, not trusted from phones.
- Orders do not subtract stock while pending/confirmed/shipped. `public.change_order_status` decrements stock atomically **once** on delivery, fails if stock is insufficient, and restores once when a delivered order is cancelled.
- Profit is a management estimate: delivered order selling value minus product costs saved on order creation minus all recorded expenses. It does not represent tax filings, VAT reporting, returns, or formal accounting.
- `collected_amount` is the cumulative amount collected, not a list of payments; changes overwrite the total.
- Currency is per business; USD and LBP are never automatically mixed or converted.
- Only an authenticated owner may read their business records, enforced by RLS policies and RPC ownership checks. This must be independently penetration-tested before launch.
- Customer phone/address is sensitive personal data. Provide privacy notice, retention/deletion policy and appropriate access controls before live customer use.

## Next engineering milestones to become app-store-ready

1. Run QA on actual Android and iOS builds; inspect accessibility, Arabic text, error handling and responsive layouts.
2. Add password reset, account deletion, privacy policy and terms.
3. Add robust loading/error handling, pagination, and an offline strategy; add full AR translations.
4. Expand reports, returns/refunds, product images, data export/import, taxes, discount/coupon logic if needed.
5. Integrate in-app subscriptions with Apple/Google policy-compliant purchase flow (e.g., RevenueCat), server-side verified entitlements and subscription screens.
6. Add telemetry/crash reporting, automated unit/integration tests, secure secret management and CI.
7. Create signing certificates, icons, splash screens, store screenshots and privacy declarations; validate Google and Apple requirements.
8. Register a commercial name only after checking availability and trademark issues.

## Security and ownership

Do not post database passwords, service-role tokens, customer lists, or Apple signing credentials into chats. `--dart-define` passes a PUBLIC app key and URL; these are not secrets. Consider using separate development and production Supabase projects. User-owned accounts are necessary to publish, operate and receive subscription payments.

## References
- https://supabase.com/docs/guides/getting-started/tutorials/with-flutter
- https://supabase.com/docs/reference/dart/auth-signup
- https://supabase.com/docs/guides/database/postgres/row-level-security
- https://docs.flutter.dev/get-started/install
- https://docs.flutter.dev/deployment/android
- https://docs.flutter.dev/deployment/ios

## Additional project docs

- `docs/SETUP_AND_TEST.md` — computer/iPhone setup and Supabase first-run testing.
- `docs/RELEASE_GATE.md` — blockers for a paid commercial release.
- `docs/QA_TEST_MATRIX.md` — test cases to run against real devices and Supabase.
- `docs/PRIVACY_POLICY_DRAFT.md` — placeholders only; legal review required before publishing.
- `.github/workflows/flutter-checks.yml` — runnable Flutter analysis/test CI on GitHub after uploading the project.

## Business contact phone

The business contact field initially contains **+96179162328**, as requested. You can edit it from **Account settings → Business contact phone**. This stores the number in your business record in Supabase. It is not automatically published on an app-store listing, shared with customers, or used as a login number. A **new** database uses `supabase/schema.sql`; an **existing** v0.2 database needs `supabase/migrations/20261103_add_business_contact_phone.sql` applied once. Only the onboarding form is prefilled for this pilot; the database itself has no phone default, so unrelated businesses will not inherit your number. Remove the onboarding prefill before a public launch.

## iOS build support (v0.4)

- `scripts/build_ios_on_mac.sh` runs Flutter analysis/tests and builds an **unsigned iOS Simulator** app on a Mac.
- `.github/workflows/ios-simulator.yml` provides the same checks on a GitHub-hosted macOS runner when pushed to a user-owned repository.
- `docs/IOS_BUILD_AND_TEST.md` includes real-device signing, Supabase integration and acceptance-test instructions.
- These are build **instructions and automation**, not proof of a successful iPhone compile. No iOS builds were run here.
