-- Only for EXISTING SellMate databases whose businesses table lacks contact_phone.
-- Run this once in Supabase SQL Editor. New databases already include the column in schema.sql.
alter table public.businesses
  add column if not exists contact_phone text;

alter table public.businesses
  drop constraint if exists businesses_contact_phone_format;
alter table public.businesses
  add constraint businesses_contact_phone_format
  check (contact_phone is null or contact_phone ~ '^\+[1-9][0-9]{7,14}$');
