-- SellMate bootstrap for a NEW Supabase project. Run ONCE in SQL Editor.
-- Financial and stock values in a single business currency (USD or LBP).
-- No client writes allowed to order_items, inventory_movements, or calculated totals.
create extension if not exists pgcrypto;

create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text not null default '',
 language text not null default 'en' check(language in ('en','ar')),
 created_at timestamptz not null default now()
);
create table public.businesses (
 id uuid primary key default gen_random_uuid(),
 owner_id uuid not null references auth.users(id) on delete cascade,
 name text not null check(length(trim(name)) between 1 and 120),
 currency text not null default 'USD' check(currency in ('USD','LBP')),
 contact_phone text check(contact_phone is null or contact_phone ~ '^\+[1-9][0-9]{7,14}$'),
 created_at timestamptz not null default now(),
 unique(owner_id)
);
create table public.products (
 id uuid primary key default gen_random_uuid(),
 business_id uuid not null references public.businesses(id) on delete cascade,
 name text not null check(length(trim(name)) between 1 and 200),
 sku text,
 cost_price numeric(16,2) not null default 0 check(cost_price>=0),
 selling_price numeric(16,2) not null check(selling_price>=0),
 quantity integer not null default 0 check(quantity>=0),
 low_stock_threshold integer not null default 5 check(low_stock_threshold>=0),
 created_at timestamptz not null default now(),
 unique(business_id,sku)
);
create table public.customers (
 id uuid primary key default gen_random_uuid(),
 business_id uuid not null references public.businesses(id) on delete cascade,
 name text not null check(length(trim(name)) between 1 and 200),
 phone text,
 address text,
 created_at timestamptz not null default now()
);
create table public.expenses (
 id uuid primary key default gen_random_uuid(),
 business_id uuid not null references public.businesses(id) on delete cascade,
 description text not null check(length(trim(description)) > 0),
 amount numeric(16,2) not null check(amount>0),
 occurred_on date not null default current_date,
 created_at timestamptz not null default now()
);
create table public.orders (
 id uuid primary key default gen_random_uuid(),
 business_id uuid not null references public.businesses(id) on delete cascade,
 customer_id uuid references public.customers(id) on delete set null,
 status text not null default 'pending' check(status in ('pending','confirmed','shipped','delivered','cancelled')),
 total numeric(16,2) not null default 0 check(total>=0),
 cost_total numeric(16,2) not null default 0 check(cost_total>=0),
 collected_amount numeric(16,2) not null default 0 check(collected_amount>=0),
 created_at timestamptz not null default now(),
 delivered_at timestamptz,
 check(collected_amount<=total)
);
create table public.order_items (
 id uuid primary key default gen_random_uuid(),
 order_id uuid not null references public.orders(id) on delete cascade,
 product_id uuid not null references public.products(id),
 product_name text not null,
 quantity integer not null check(quantity>0),
 unit_price numeric(16,2) not null check(unit_price>=0),
 unit_cost numeric(16,2) not null check(unit_cost>=0)
);
create table public.inventory_movements (
 id uuid primary key default gen_random_uuid(),
 business_id uuid not null references public.businesses(id) on delete cascade,
 product_id uuid not null references public.products(id),
 order_id uuid references public.orders(id),
 delta integer not null check(delta<>0),
 reason text not null,
 created_at timestamptz not null default now()
);

create index on public.products(business_id);
create index on public.customers(business_id);
create index on public.orders(business_id, created_at desc);
create index on public.expenses(business_id, occurred_on desc);
create index on public.inventory_movements(business_id, created_at desc);

create or replace function public.on_auth_signup() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
 insert into public.profiles(id,full_name)
 values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''));
 return new;
end; $$;
create trigger create_profile after insert on auth.users
for each row execute function public.on_auth_signup();

-- All tables deny anon; direct client writes only to simple business resources.
do $$ declare t text; begin
 foreach t in array array['profiles','businesses','products','customers','expenses','orders','order_items','inventory_movements'] loop
  execute format('alter table public.%I enable row level security',t);
  execute format('revoke all on public.%I from anon, authenticated',t);
 end loop;
end $$;
grant select,insert,update on public.profiles,public.businesses,public.products,public.customers,public.expenses to authenticated;
grant delete on public.products,public.customers,public.expenses to authenticated;
grant select on public.orders,public.order_items,public.inventory_movements to authenticated;

create policy profile_read on public.profiles for select to authenticated using(id=(select auth.uid()));
create policy profile_update on public.profiles for update to authenticated using(id=(select auth.uid())) with check(id=(select auth.uid()));
create policy business_read on public.businesses for select to authenticated using(owner_id=(select auth.uid()));
create policy business_insert on public.businesses for insert to authenticated with check(owner_id=(select auth.uid()));
create policy business_update on public.businesses for update to authenticated using(owner_id=(select auth.uid())) with check(owner_id=(select auth.uid()));

create or replace function public.owns_business(p_business uuid) returns boolean
language sql stable security definer set search_path = '' as $$
 select exists(select 1 from public.businesses where id=p_business and owner_id=(select auth.uid()));
$$;
revoke all on function public.owns_business(uuid) from public;
grant execute on function public.owns_business(uuid) to authenticated;

create policy products_all on public.products for all to authenticated using(public.owns_business(business_id)) with check(public.owns_business(business_id));
create policy customers_all on public.customers for all to authenticated using(public.owns_business(business_id)) with check(public.owns_business(business_id));
create policy expenses_all on public.expenses for all to authenticated using(public.owns_business(business_id)) with check(public.owns_business(business_id));
create policy orders_read on public.orders for select to authenticated using(public.owns_business(business_id));
create policy items_read on public.order_items for select to authenticated using(exists(select 1 from public.orders o where o.id=order_id and public.owns_business(o.business_id)));
create policy movements_read on public.inventory_movements for select to authenticated using(public.owns_business(business_id));

-- IMPORTANT: no direct UPDATE allowed to product quantity by app role:
-- Use a trigger to record manual stock changes. Prevent order-specific changes
-- from bypassing the server functions via protected RPC-only operations.
create or replace function public.record_manual_stock() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
 if TG_OP='INSERT' and NEW.quantity>0 then
  insert into public.inventory_movements(business_id,product_id,delta,reason)
  values(NEW.business_id,NEW.id,NEW.quantity,'opening_stock');
 elsif TG_OP='UPDATE' then
  if OLD.business_id<>NEW.business_id then raise exception 'Cannot change product business'; end if;
  if NEW.quantity<>OLD.quantity and coalesce(current_setting('sellmate.stock_rpc',true),'') <> 'on' then
   insert into public.inventory_movements(business_id,product_id,delta,reason)
   values(NEW.business_id,NEW.id,NEW.quantity-OLD.quantity,'manual_adjustment');
  end if;
 end if;
 return NEW;
end; $$;
create trigger track_stock after insert or update on public.products
for each row execute function public.record_manual_stock();

-- Single atomic transaction validates product ownership and calculates totals.
create or replace function public.create_order(p_business uuid, p_customer uuid, p_items jsonb)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_order uuid; v_item jsonb; v_prod public.products%rowtype; v_qty integer;
 v_total numeric(16,2):=0; v_cost numeric(16,2):=0; v_count int:=0;
begin
 if not public.owns_business(p_business) then raise exception 'Not authorized'; end if;
 if p_customer is not null and not exists(select 1 from public.customers where id=p_customer and business_id=p_business) then
  raise exception 'Invalid customer'; end if;
 if jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 or jsonb_array_length(p_items)>100 then
  raise exception 'Order requires 1 to 100 items'; end if;
 insert into public.orders(business_id,customer_id) values(p_business,p_customer) returning id into v_order;
 for v_item in select value from jsonb_array_elements(p_items) loop
  v_count:=v_count+1;
  if (v_item->>'quantity') !~ '^[0-9]+$' then raise exception 'Invalid quantity'; end if;
  v_qty:=(v_item->>'quantity')::integer;
  if v_qty<1 or v_qty>100000 then raise exception 'Invalid quantity'; end if;
  select * into v_prod from public.products where id=(v_item->>'product_id')::uuid and business_id=p_business for update;
  if not found then raise exception 'Invalid product'; end if;
  insert into public.order_items(order_id,product_id,product_name,quantity,unit_price,unit_cost)
  values(v_order,v_prod.id,v_prod.name,v_qty,v_prod.selling_price,v_prod.cost_price);
  v_total:=v_total+(v_prod.selling_price*v_qty); v_cost:=v_cost+(v_prod.cost_price*v_qty);
 end loop;
 update public.orders set total=v_total,cost_total=v_cost where id=v_order;
 return v_order;
end; $$;

-- Stock is committed on delivery; cancellation of delivered orders restores it.
-- Note: restocking a cancelled order is not a customer return flow.
create or replace function public.change_order_status(p_order uuid, p_status text)
returns void language plpgsql security definer set search_path = '' as $$
declare v_order public.orders%rowtype; v_item record; v_current integer;
begin
 select * into v_order from public.orders where id=p_order for update;
 if not found or not public.owns_business(v_order.business_id) then raise exception 'Not authorized'; end if;
 if p_status not in ('pending','confirmed','shipped','delivered','cancelled') then raise exception 'Invalid status'; end if;
 if v_order.status='cancelled' then raise exception 'Cancelled orders are final'; end if;
 if v_order.status='delivered' and p_status not in ('delivered','cancelled') then raise exception 'Delivered orders are final except cancellation'; end if;
 if v_order.status=p_status then return; end if;
 if p_status='delivered' then
  perform set_config('sellmate.stock_rpc','on',true);
  for v_item in select product_id,sum(quantity)::int as qty from public.order_items where order_id=p_order group by product_id order by product_id loop
   select quantity into v_current from public.products where id=v_item.product_id and business_id=v_order.business_id for update;
   if v_current<v_item.qty then raise exception 'Insufficient stock'; end if;
   update public.products set quantity=quantity-v_item.qty where id=v_item.product_id;
   insert into public.inventory_movements(business_id,product_id,order_id,delta,reason)
    values(v_order.business_id,v_item.product_id,p_order,-v_item.qty,'delivered_order');
  end loop;
 elsif p_status='cancelled' and v_order.status='delivered' then
  perform set_config('sellmate.stock_rpc','on',true);
  for v_item in select product_id,sum(quantity)::int as qty from public.order_items where order_id=p_order group by product_id order by product_id loop
   update public.products set quantity=quantity+v_item.qty where id=v_item.product_id;
   insert into public.inventory_movements(business_id,product_id,order_id,delta,reason)
    values(v_order.business_id,v_item.product_id,p_order,v_item.qty,'cancelled_delivery');
  end loop;
 end if;
 perform set_config('sellmate.stock_rpc','off',true);
 update public.orders set status=p_status, delivered_at=case when p_status='delivered' then now() else null end where id=p_order;
end; $$;

create or replace function public.set_order_collection(p_order uuid,p_amount numeric)
returns void language plpgsql security definer set search_path = '' as $$
declare v_order public.orders%rowtype;
begin
 select * into v_order from public.orders where id=p_order for update;
 if not found or not public.owns_business(v_order.business_id) then raise exception 'Not authorized'; end if;
 if p_amount<0 or p_amount>v_order.total then raise exception 'Invalid collection amount'; end if;
 update public.orders set collected_amount=p_amount where id=p_order;
end; $$;
revoke all on function public.create_order(uuid,uuid,jsonb) from public;
revoke all on function public.change_order_status(uuid,text) from public;
revoke all on function public.set_order_collection(uuid,numeric) from public;
grant execute on function public.create_order(uuid,uuid,jsonb),public.change_order_status(uuid,text),public.set_order_collection(uuid,numeric) to authenticated;
