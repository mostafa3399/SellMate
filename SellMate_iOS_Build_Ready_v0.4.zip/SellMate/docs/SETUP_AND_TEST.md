# SellMate — Owner setup and first-device test

The archive is a **Flutter source project**, not a compiled APK or IPA. The app requires your Supabase URL and publishable key. The code and database are not connected to your accounts by this archive.

## On your Windows or Mac

1. Install current stable Flutter, Git and Android Studio. On macOS, install Xcode for iOS. Run `flutter doctor` and resolve the errors.
2. Extract the project. In the `SellMate` directory run `flutter create --platforms=android,ios .`, then `flutter pub get`. This creates missing native Android/iOS scaffolding. **Keep the provided** `lib/`, `test/`, `pubspec.yaml`, and `supabase/` files.
3. Run `flutter analyze`, then `flutter test`. Resolve toolchain errors before assuming the app runs.
4. Create a fresh Supabase project you control. Run `supabase/schema.sql` **once** in the SQL Editor. Don't run this bootstrap over existing SellMate tables: migrate or start fresh.
5. Supabase → Authentication → Providers → Email: enable email/password, choose whether to require email confirmation (recommended); configure SMTP for production. Set site URL and allowed redirect URLs for recovery/confirmation emails.
6. Copy only your **project URL** and **publishable (or anon) API key**. **Never copy a database password, secret key or service-role key into the app**.
7. Android test: connect Android device or start emulator, then run:

   `flutter run --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_PUBLIC_KEY`

8. iPhone test: must use a Mac with Xcode. Configure the iOS team/bundle ID and signing, select your iPhone, and run the same Flutter command. For email confirmation and password recovery on a physical device, configure **deep links/Universal Links** in the native projects and Supabase redirect allow-list before relying on those flows.
9. Create a test user, confirm email, create a business in USD, create 2 products, restart app, ensure product data is still present, add a customer and order, mark delivered, confirm quantity decreases exactly once. Mark order cancelled and confirm stock restores. Verify you cannot query another business's records under a separate account.

## Arabic and currencies

Use the Settings menu to switch English/Arabic. RTL is automatic via Flutter locale. Some system and backend error text remains provider-supplied and untranslated; review on real devices. USD and LBP are **independent business base currencies**; there is no automatic FX conversion or cross-currency accounting.

## Password recovery

The app can request a recovery email and accept a Supabase `passwordRecovery` auth event with a password-update screen. You **must** configure a valid return URL/deep link for this to work on native devices. Test on iOS and Android before release.

## Common errors

- `Missing Supabase configuration` → rerun with both `--dart-define` values.
- `relation ... does not exist` → schema SQL has not been installed on the project you connected.
- `row-level security` / unauthorized → check authenticated session, business owner and linked IDs, not RLS bypasses.
- App cannot open reset link → configure callback URL, Android intent filters/iOS associated domains and the Supabase allow-list.
- iOS build fails on Windows → iOS compilation and signing require macOS/Xcode.

## Requested business contact number

The onboarding contact phone initially reads `+96179162328`. It is editable under **Account settings**, and stored in `businesses.contact_phone`. To update an existing database from v0.2, run `supabase/migrations/20261103_add_business_contact_phone.sql` once rather than re-running the bootstrap. Confirm the phone is saved and editable. This field is private owner data in the current application. Remove the onboarding prefill before enabling unrelated businesses to sign up commercially.
