# SellMate: iPhone compilation and real-device acceptance test

**State of this delivery:** iOS build automation and instructions have been added. No actual iOS build or iPhone test was run by the assistant. This workspace uses Linux and has no Flutter SDK or Xcode. The existing codebase is source-level only, not an IPA.

## A. Fast compilation check (requires a Mac)

Install Flutter stable and Xcode from their official sources. Open Xcode once, accept the license, install iOS simulator runtimes, and complete `flutter doctor -v`. From the SellMate project directory:

```bash
./scripts/build_ios_on_mac.sh
```

The script generates Flutter's missing native `ios/` folder, resolves dependencies, executes analysis and tests, then compiles an unsigned **simulator** application. If any step fails, it stops without saying the app is ready. The script deliberately does not apply a live Supabase key: compilation alone does not test account flows.

Alternatively, upload the entire project to a *private GitHub repository*, enable Actions, and run the `iOS simulator build (unsigned)` workflow. This requires user-controlled GitHub access and triggers a macOS-hosted runner. Its result may contain an unsigned simulator ZIP, **not** an installable phone IPA. GitHub-hosted builds require the project to be in your GitHub repository; no workflow has been run on your behalf.

## B. Connect your own test Supabase project

1. Create a NEW Supabase project, and run `supabase/schema.sql` exactly once in its SQL Editor.
2. Enable Email auth and configure test confirmation behavior. Do not put any `service_role` key in Flutter.
3. In a terminal, set the public configuration for your own test project:

```bash
flutter run -d "YOUR_IPHONE_DEVICE_ID" \
  --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=YOUR_PUBLIC_PUBLISHABLE_KEY
```

`flutter devices` lists connected devices. A developer may pass these public values via IDE run configuration instead. They still expose the backend URL and public client key to anyone with the app, which is expected; database security must be provided by RLS.

## C. Install on a real iPhone (Mac + Xcode required)

1. On the iPhone: connect via USB, tap **Trust**, and enable **Settings → Privacy & Security → Developer Mode** if prompted; follow the restart prompts.
2. Generate iOS scaffolding first using the script, then open `ios/Runner.xcworkspace` in Xcode.
3. Select **Runner → Signing & Capabilities** and enable automatic signing. Set a unique bundle identifier you own (not the default placeholder) and your appropriate Apple development team. This action needs your Apple account and may require an eligible adult account holder.
4. In Xcode select the connected iPhone and run the app, or return to Terminal and use `flutter devices` then `flutter run -d DEVICE_ID` with the two Supabase `--dart-define` values.
5. Check the device trust prompt under **Settings → General → VPN & Device Management** if required.

An unsigned simulator ZIP cannot be installed on an ordinary iPhone. A signed TestFlight or App Store release additionally requires Apple Developer enrollment, valid certificates/profiles, an App Store Connect record, and release review.

## D. Acceptance test, on a physical iPhone

Complete all these checks with **test users and fictitious customer data only**:

- [ ] Launch works on Wi-Fi and on mobile data, both fresh and after force quit.
- [ ] Sign up, confirm email, sign in, sign out, sign in again.
- [ ] Password reset works end-to-end (native callback/deep-link setup is still pending).
- [ ] Create business, choose USD, verify phone field is editable and stored.
- [ ] Add product A with quantity 10, product B with quantity 3, force quit, reopen; both persist.
- [ ] Edit price and quantity and check Supabase `inventory_movements` audit records.
- [ ] Create customer and order with 2× product A; server, not phone, determines price.
- [ ] Mark delivered once; product A stock becomes 8. Attempt duplicate delivery; stock stays 8.
- [ ] Cancel delivered order; stock returns to 10 once.
- [ ] Try to deliver with insufficient stock; transaction fails and stock stays unchanged.
- [ ] Check partial cash collection and reports before and after delivery.
- [ ] Change app language to Arabic; confirm RTL navigation and no clipped labels.
- [ ] Run iPhone at small text and large accessibility text; check buttons and form fields.
- [ ] Connect a different account; confirm that user cannot view or alter the first account's records.
- [ ] Disconnect internet, retry actions; confirm errors do not imply the action succeeded.

## E. Known blockers to a commercial release

Not yet complete: actual iPhone compile/test results, production Supabase deployment, native password recovery deep links, store-compliant account deletion, complete Arabic translation, comprehensive security assessment, public privacy policy, in-app monthly subscriptions, and signed TestFlight/App Store builds. Do not collect real customer data or sell subscriptions until these are addressed.

## Official reference

- https://docs.flutter.dev/platform-integration/ios/setup
- https://docs.flutter.dev/deployment/ios
- https://developer.apple.com/documentation/xcode/running-your-app-on-simulated-or-physical-devices
