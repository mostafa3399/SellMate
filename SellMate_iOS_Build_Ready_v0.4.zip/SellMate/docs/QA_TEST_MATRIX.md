# Manual QA matrix

| Case | Steps | Expected |
|---|---|---|
| Sign up | Register with new email, confirm | Profile created once; session works |
| Wrong login | Invalid password | No access; clear error |
| Recovery | Request link, open on same phone, set new password | Password updated after auth recovery callback |
| New business | Create USD business | Exactly one business created, currency fixed |
| Add products | Add 3 products incl. low-stock | Products persistent and low-stock appears |
| Edit inventory | Increase 5→7 | Quantity updates; movement +2 recorded |
| New order | Select customer, 2 products | Server saves correct total; quantity unchanged while pending |
| Delivered | Mark order delivered | Stock decreases once; movement recorded |
| Idempotency | Try delivered again | No duplicate stock movement |
| Insufficient stock | Attempt delivery without stock | Transaction rejected, no negative stock |
| Cancel delivered | Cancel delivered order | Stock returns once; cash requires review |
| Cash collected | Enter amount over total | Server rejects |
| Data isolation | Authenticate account B and query account A | RLS/RPC denies |
| Currency | Switch new test business to LBP | No hidden automatic USD conversion |
| Report filters | Compare all time vs this month vs 30 days | Sales/expenses filtered correctly |
| Arabic | Toggle and navigate every screen | RTL layout and legible text; note untranslated backend errors |
| Disconnect | Disable mobile internet during save | No silent success; user gets failure |
| Persistence | Force quit/reopen | Products, customer/order data still there |
| App lifecycle | Background/foreground, login/logout | No crash or data leakage |


## Business phone tests (v0.3)

- [ ] Fresh sign-up → business setup shows +96179162328 in the phone field.
- [ ] A new business saves the chosen phone to `businesses.contact_phone`.
- [ ] Account Settings displays the saved number.
- [ ] Edit the phone to another valid E.164 number, reopen Settings and confirm the saved update.
- [ ] Invalid values without `+`, or too short, do not save.
- [ ] A second independent account has no default number at the database level and cannot access the first account's business phone.
- [ ] Remove the pilot onboarding prefill before releasing the app for other merchants.
