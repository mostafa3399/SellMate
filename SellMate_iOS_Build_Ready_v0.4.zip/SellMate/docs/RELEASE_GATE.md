# Release gate — do not submit before completing

## Implemented in repository (source-level only)

- Cross-platform Flutter views, account flow, onboarding, product management, inventory change log, customers, order lifecycle, cash collected and period-filtered basic reports.
- Basic Arabic and English UI labels and direction.
- Supabase SQL with row-level security, RPC-calculated order totals and transactional stock updates.
- Request password reset and recovery-state UI; working callback requires native deep-link setup.

## Blocking release tasks (not done)

- Remove the pilot business-phone prefill (+96179162328) before general-public distribution. Obtain explicit permission before displaying any business number to customers.

- Create own Supabase project; configure production authentication/SMTP/redirects; perform RLS and RPC adversarial tests.
- Compile, run `flutter analyze` and `flutter test` with an installed SDK; test on Android + iOS real devices; fix discovered errors.
- Add user-initiated account deletion (including Supabase Auth identity and personal data), data export, and retention controls; validate app-store account deletion requirements.
- Review UX/accessibility, screen-reader labels, full Arabic coverage, error strings, currency precision, RTL layout, offline/network failures and production performance.
- Integrate legitimate recurring subscriptions with Apple/Google billing through a supported service (e.g. RevenueCat), verify server-side entitlements and product mapping; create products in both stores. Current app remains free and **does not charge users**.
- Configure signed iOS/Android native projects, bundle IDs, notification/deep-link settings, icons, launch screens, store screenshots, descriptions and age/privacy/data-safety declarations.
- Establish privacy policy, terms, support address, incident response, backup policy, analytics consent and legal/compliance review for Lebanon + later countries.
- Trademark/name check for SellMate; business/tax/payment setup and developer registrations under eligible account owners.
- Add monitoring, crash reports, rollback plan, database backups, rate limits and load/security testing.

## Accounting limitations

Management estimates are not certified accounting. Reports only include delivered-order revenue, frozen order-cost snapshot and recorded expenses; cash collection is cumulative, not a payment ledger. Historic inventory adjustments, tax, refunds, multi-currency and returns are out of scope. For launch, expand financial logic based on pilot customer feedback and local accountant review.
