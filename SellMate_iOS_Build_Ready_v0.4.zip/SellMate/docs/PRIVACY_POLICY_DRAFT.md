# SellMate privacy policy — DRAFT ONLY (NOT FOR PUBLICATION)

**Owner/operator legal name:** [INSERT]
**Contact:** [INSERT BUSINESS EMAIL]
**Effective date:** [INSERT]
**Hosting region:** [INSERT ACTUAL SUPABASE PROJECT REGION]

SellMate may collect account email/name, business name, product and stock records, customer names/telephone numbers/addresses entered by merchants, order and cost records, and technical records needed for security and operation. The operator must document exactly which data are collected and which processors receive them (including Supabase and any future analytics or billing partner).

The application is intended for merchant use. Merchants are responsible for ensuring they have lawful grounds to record their customers' information, within applicable privacy requirements. The application operator must specify relevant lawful bases, retention periods, deletion/data-access procedures, international transfers, and security arrangements. Subscription receipts and account identifiers may be processed by app stores and billing providers when billing is enabled.

**Before publication:** replace all placeholders; define an effective request-response process for access, correction and deletion; implement account deletion in the product; verify local/international legal obligations with qualified counsel; publish the final URL and add it to the app and the store listings.
