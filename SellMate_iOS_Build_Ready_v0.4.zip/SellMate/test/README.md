# Required tests before release

The application has not been run in an Android or iOS emulator in this environment.

1. Create accounts A and B. Ensure B cannot read/update A's rows, even via direct REST calls.
2. Create a product with 5 units. Create order for 3. Stock stays 5 while pending.
3. Deliver order: stock is 2. Deliver again: stock stays 2.
4. Create another order for 3. Delivery should fail without changing stock/status.
5. Cancel delivered first order: stock returns to 5. Cancel again: no additional restock.
6. Changing order totals through client APIs is denied.
7. Changing order line items directly is denied.
8. Verify email confirmation and account re-entry after restarting app.
9. Verify Arabic text direction and long Arabic strings on real phone.
10. Verify unsupported currencies are rejected; don't assume exchange conversion.
11. Test 100+ products, loading indicators, offline/error states, and application restart.
12. Confirm subscription/payment/store requirements before release.
