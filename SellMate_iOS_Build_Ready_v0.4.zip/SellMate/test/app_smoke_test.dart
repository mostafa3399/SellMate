import 'package:flutter_test/flutter_test.dart';
import 'package:sellmate/main.dart';

void main() {
  test('English and Arabic label mapping', () {
    expect(I18n.t('dashboard', false), 'Dashboard');
    expect(I18n.t('dashboard', true), 'لوحة التحكم');
  });
  test('Money displays correct currency without conversion', () {
    expect(money(1200, 'LBP').startsWith('LBP '), isTrue);
    expect(money(12, 'USD').startsWith(r'$'), isTrue);
  });
}
