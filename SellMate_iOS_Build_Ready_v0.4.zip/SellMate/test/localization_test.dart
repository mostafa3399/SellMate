import 'package:flutter_test/flutter_test.dart';
import 'package:sellmate/main.dart';

void main() {
  test('Important onboarding and financial labels are bilingual', () {
    for (final key in <String>[
      'dashboard', 'products', 'orders', 'customers', 'reports',
      'login', 'signup', 'business', 'currency', 'add_product',
      'save_order', 'profit', 'expenses', 'report_period',
      'recovery_title', 'update_password', 'delete_product',
    ]) {
      expect(I18n.labels.containsKey(key), isTrue, reason: key);
      expect(I18n.t(key, true).isNotEmpty, isTrue, reason: key);
      expect(I18n.t(key, false).isNotEmpty, isTrue, reason: key);
    }
  });
}
